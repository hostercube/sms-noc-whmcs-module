<?php
$msgs=[
    'AcceptOrder'   =>  'හිතවත් {firstname} {lastname}, ඔබේ ඇණවුම, (ඇණවුම් අංක {orderid}) අනුමත කර ඇත.',
    'AdminLogin'    =>  '{username} පරිශීලක නාමය ඇති පරිශීලකයෙකු පරිපාලක පැනලයට ඇතුළු වී ඇත',
    'AfterModuleChangePackage'  =>  'හිතවත් {firstname} {lastname}, ඔබේ {domain} සම්බන්ධව ඇති නිෂ්පාදන / සේවා පැකේජය වෙනස් කර ඇත. වැඩි විස්තර සඳහා කරුණාකර අප හා සම්බන්ධ වන්න',
    'AfterModuleChangePassword' =>  'හිතවත් {firstname} {lastname}, {domain} සම්බන්ධව ඇති මුරපදය සාර්ථකව වෙනස් කර ඇත. විස්තර - පරිශීලක නාමය: {username} මුරපදය: {password}',
    'AfterModuleCreate' =>  '{domain} සදහා සේවාවන්  දැන් සක්‍රීය කර ඇත. ගිණුම් සඳහා පිවිසුම් විස්තර - පරිශීලක නාමය:{username} මුරපදය: {password}',
    'AfterModuleSuspend'    =>  ''
];
?>